//
//  SearchView.swift
//  FoodieFoodie
//
//  Created by 한승수 on 2022/11/29.
//

import SwiftUI

struct SearchView: View {
    @State private var input = ""
    var body: some View {
        VStack {
            HStack {
                TextField("취향저격 뿌레터를 검색해보세요", text: $input)
                Image(systemName: "magnifyingglass")
            }
            .padding(EdgeInsets(top: -85, leading: 50, bottom: 0, trailing: 20))
            Image("SearchFrame")
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
}
