//
//  FoodieFoodieApp.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI

@main
struct FoodieFoodieApp: App {
    var body: some Scene {
        WindowGroup {
            LogoView()
        }
    }
}
