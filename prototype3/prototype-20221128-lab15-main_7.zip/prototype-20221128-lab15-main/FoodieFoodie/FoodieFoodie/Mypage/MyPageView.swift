//
//  MyPageView.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI

struct MyPageView: View {
    var body: some View {
        VStack {
            HStack(alignment: .center, spacing: 5) {
                Image("silverBadge")
                    .resizable()
                    .frame(width: 35, height: 35)
                    .padding(.leading, 15)
                
                Text("배고파")
                    .font(.title)
                    .bold()
                
                Spacer()
            }
            .padding(EdgeInsets(top: 30, leading: 5, bottom: 15, trailing: 0))
            
            HStack {
                Image("profile")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .cornerRadius(100)
                    .padding(5)
                
                VStack {
                    Text("2")
                    Text("게시물")
                        .font(.subheadline)
                }
                .padding()
                
                VStack {
                    Text("100")
                    Text("팔로워")
                        .font(.subheadline)
                }
                .padding()
                
                VStack {
                    Text("100")
                    Text("팔로잉")
                        .font(.subheadline)
                }
                .padding()
            }
            
            HStack {
                Text("맛집 탐방 중...🔭")
                    .font(.subheadline)
                    .padding(EdgeInsets(top: 15, leading: 30, bottom: 20, trailing: 0))
                
                Spacer()
            }
            
            Divider()
            
            Spacer()
            
        } // VStack
    } // body
}

struct MyPageView_Previews: PreviewProvider {
    static var previews: some View {
        MyPageView()
    }
}
