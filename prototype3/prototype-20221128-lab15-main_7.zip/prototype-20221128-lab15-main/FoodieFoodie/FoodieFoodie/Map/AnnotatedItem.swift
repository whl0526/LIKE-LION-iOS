//
//  AnnotatedItem.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import Foundation
import CoreLocation

struct AnnotatedItem: Identifiable {
    let id = UUID()
    var name: String
    var coordinate: CLLocationCoordinate2D
}
