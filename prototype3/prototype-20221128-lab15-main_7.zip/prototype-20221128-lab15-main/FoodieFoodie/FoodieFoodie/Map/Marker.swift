//
//  Marker.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI

struct Marker : Codable, Identifiable {
    var id: String
    var name: String
    var latitude: Double
    var longitude: Double
    var link: String
    var bgColor: String
    var icon: String
    var image: [String]
    var hasFutory: Bool
}
