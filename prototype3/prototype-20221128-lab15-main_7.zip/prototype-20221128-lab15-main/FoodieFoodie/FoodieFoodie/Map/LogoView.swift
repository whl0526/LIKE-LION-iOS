//
//  LogoView.swift
//  FoodieFoodie
//
//  Created by 박민주 on 2022/11/30.
//

import SwiftUI
import Shimmer

struct LogoView: View {
    
    @State private var isActive = false
    @State private var opacity = 0.7
    @State private var size = 0.8
   
    
    var body: some View {
        
        if isActive {
            ContentView()
        } else {
            ZStack {
                Color(.white)
                    .ignoresSafeArea()
                VStack {
                    VStack {
                        Image("logo")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .shimmering()
             
                    }
                    .scaleEffect(size)
                    .opacity(opacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 2)) {
                            self.size = 0.9
                            self.opacity = 1.0
                        }
                    }
                }
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

struct LogoView_Previews: PreviewProvider {
    static var previews: some View {
        LogoView()
    }
}
