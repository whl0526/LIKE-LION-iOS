//
//  MarkerViewModel.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//
import SwiftUI
import Combine
import CoreLocation

class MarkerViewModel : ObservableObject {
    
    @Published var marker: [Marker]
    
    init (marker: [Marker] = []) {
        self.marker = marker
    }
    
    func getAnnotatedItemList() -> [AnnotatedItem] {
        
        var annotationItemList = [AnnotatedItem]()
        
        for item in marker {
            let cordinate = CLLocationCoordinate2D(latitude: item.latitude, longitude: item.longitude)
            annotationItemList.append(AnnotatedItem(name: item.name , coordinate: cordinate))
        }
        
        return annotationItemList
    }
    
}
