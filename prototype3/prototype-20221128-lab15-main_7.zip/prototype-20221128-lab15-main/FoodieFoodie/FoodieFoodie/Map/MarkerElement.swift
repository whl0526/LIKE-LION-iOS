//
//  MarkerElement.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/30.
//

import SwiftUI

struct MarkerElement: View {
    var icon: String = ""
    var hasFutory: Bool?
    
    @State private var isRotating : Double = 0.0
    
    var body: some View {
        ZStack {
            Circle()
                .frame(width: 50)
                .foregroundColor(.orange)
//                                        .shadow(color: .orange, radius: 10)
            Circle()
                .frame(width: 45)
                .foregroundColor(.white)
            Text(icon)
            if hasFutory ?? false {
                Image(systemName: "star.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 12)
                    .foregroundColor(.orange)
                    .offset(y: -25)
                    .shadow(color: .yellow, radius: 1)
                    .rotationEffect(.degrees(isRotating))
                    .onAppear {
                        withAnimation(.linear(duration: 1) 
                            .speed(0.2).repeatForever(autoreverses: false)) {
                            isRotating = 360.0
                        }
                    }
            }
            
        }
    }
}

struct MarkerElement_Previews: PreviewProvider {
    static var previews: some View {
        MarkerElement(icon: "☕️", hasFutory: true)
    }
}
