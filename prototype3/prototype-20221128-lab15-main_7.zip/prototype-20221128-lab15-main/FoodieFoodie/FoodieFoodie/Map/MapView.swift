//
//  MapView.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI
import MapKit

struct MapView: View {
    
    @ObservedObject var markerStore : MarkerViewModel = MarkerViewModel(marker: markerData)
    
    @State private var region: MKCoordinateRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.524051, longitude: 127.039),
        span: MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
    )

    
    @State private var isModalOpened: Bool = true
    @State private var isClickMarker: Bool = false
    @State private var isImageClick: Bool = false
    @State private var selectMarker: Marker = markerData[0]
    
    var body: some View {
        
        GeometryReader { geometry in
            ZStack {
                Map(coordinateRegion: $region,
                    annotationItems: markerStore.marker
                ) { item in
                    //                    MapMarker(coordinate: item.coordinate)
                    MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: item.latitude, longitude: item.longitude)) {
                        VStack(spacing: 0) {
                            Button {
                                isClickMarker = true
                                isModalOpened = true
                                isImageClick = true
                                selectMarker = item
                            } label: {
                                MarkerElement(icon: item.icon, hasFutory: item.hasFutory)
                            }.padding(.bottom, 10)
                            
                            
                            Text(item.name)
                                .foregroundColor(.black)
                                .bold()
                                .font(.system(size: 12))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 2)
                                .background(.white)
                                .cornerRadius(10)
                 
                        }
                    }
                }
                
                VStack{
                    MapTopView()
                        .padding(.top, geometry.safeAreaInsets.top)
                    Spacer()
                    HStack {
                        Spacer()
                        MapBottomView(isClickMarker: $isClickMarker, region: $region)
                            .padding(.trailing, 10)
                            .padding(.bottom, isClickMarker ? geometry.size.height * 0.1 + 10 : 10)
                            .animation(.easeInOut(duration: 0.3), value: isClickMarker)
                    } // HStack
                } // VStack
            } // ZStack
            .edgesIgnoringSafeArea(.top)
            .onAppear{
                region = MKCoordinateRegion(
                    center: CLLocationCoordinate2D(latitude: 37.524051, longitude: 127.039),
                    span: MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
                    // span이 보이는 영역을 설정해준다
                    // 이 값이 줄어들을 수록 확대되어 보인다.
                    //    37.524051,
                    //    "longitude":127.040978,
                )
            }
            .sheet(isPresented: $isModalOpened) {
                MapBottomModalView(selectMarker: selectMarker, isImageClick: $isImageClick)
                    .presentationDetents([.large, .fraction(0.4)])
            }
        } // GeometryReader
    }
}



struct MapBottomView: View {
    
    @Binding var isClickMarker: Bool
    @Binding var region: MKCoordinateRegion
    
    var body: some View {
        
        VStack {
            Button {
                region =  MKCoordinateRegion(
                    center: CLLocationCoordinate2D(latitude: 37.5471774, longitude: 127.047337),
                    span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
                )
            } label: {
                Image(systemName: "scope")
                    .resizable()
                    .foregroundColor(.black)
                    .scaledToFit()
                    .frame(width:23, height: 23)
                    .padding(14)
            }
            .background(.white)
            .cornerRadius(40)
            .shadow(color: .black ,radius:1, x:0, y:1)
            
            Button {
                
            } label: {
                Image(systemName: "plus")
                    .resizable()
                    .foregroundColor(.black)
                    .scaledToFit()
                    .frame(width:20, height: 20)
                    .padding(15)
            }
            .background(.white)
            .cornerRadius(40)
            .shadow(color:.black ,radius:1, x:0, y:2)
            
        } // VStack
    }
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView()
    }
    
}

