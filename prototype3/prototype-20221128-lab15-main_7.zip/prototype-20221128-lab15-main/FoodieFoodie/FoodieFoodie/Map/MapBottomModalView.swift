//
//  MapBottomModalView.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI


extension UIScreen {
    static let screenWidth = UIScreen.main.bounds.size.width
    static let screenHeight = UIScreen.main.bounds.size.height
}

struct MapBottomModalView: View {
    let selectMarker: Marker
    @Binding var isImageClick: Bool
    
    var body: some View {
        ScrollView {
            if isImageClick {
                Image("laPalace")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                Image("mapViewModal")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
            
        }
    }
}

struct MapBottomModalView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            MapBottomModalView(selectMarker: markerData[0], isImageClick: .constant(false))
        }
    }
}
