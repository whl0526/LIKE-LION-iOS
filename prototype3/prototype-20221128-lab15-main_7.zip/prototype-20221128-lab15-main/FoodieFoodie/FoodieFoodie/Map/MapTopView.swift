//
//  MapTopView.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI

struct MapTopView: View {
    
    var tags: [String] = ["👋 영업중", "☕️ 카페", "🍚 한식", "🥟 중식", "🍣 일식", "🍝 양식", "🥢 아시안" ]
    
    var body: some View {
        VStack {
            Button {
                
            } label: {
                HStack {
                    Text("오늘은 뭘 먹을까?")
                        .font(.body)
                        
                        .foregroundColor(.gray)
                        .frame(height: 52)
                        .padding(.leading, 20)
                    Spacer()
                    Button {
                    } label: {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.black)
                    }
                    .padding(.trailing, 20)
                    
                } // HStack
            }
            .overlay( // 카드 테두리
                RoundedRectangle(cornerRadius: 20)
                    .stroke(.orange, lineWidth: 2)
                    .frame(height: 52)
            )
            .background(.white)
            .cornerRadius(20)
            .shadow(color: Color(white: 0, opacity: 0.1) ,radius:4, x:0, y:4)
            .padding([.leading, .trailing, .bottom], 10)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(tags, id: \.self) { tag in
                        Button {
                            
                        } label: {
                            Text(tag)
                                .foregroundColor(.black)
                                .padding()
                                .fontWeight(.semibold)
                                .font(.caption)
                        }
                        .background(.white)
                        .frame(height: 31)
                        .cornerRadius(20)
                        .shadow(color: Color(white: 0, opacity: 0.1) ,radius:4, x:0, y:4)
    
                    }
                }
                .padding([.horizontal, .bottom], 20)
            }//ScrollView
            
        } // HStack
    }
}

struct MapTopView_Previews: PreviewProvider {
    static var previews: some View {
        MapTopView()
    }
}
