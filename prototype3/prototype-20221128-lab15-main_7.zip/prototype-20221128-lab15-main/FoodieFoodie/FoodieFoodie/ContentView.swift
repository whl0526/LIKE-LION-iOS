//
//  ContentView.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI

struct ContentView: View {
    @State private var tabSelection: Int = 1
    
    var body: some View {
        TabView(selection: $tabSelection) {
            HomeView().tabItem {
                Label("뿌디뿌디", systemImage: "newspaper")
                    
            }.tag(1)
            MapView().tabItem {
                Label("뿌디지도", systemImage: "map")
            }.tag(2)
            MyPageView().tabItem {
                Label("나의 뿌디", systemImage: "person")
            }.tag(3)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
