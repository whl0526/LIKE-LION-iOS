//
//  HomeView.swift
//  FoodieFoodie
//
//  Created by Martin on 2022/11/29.
//

import SwiftUI
import Shimmer

struct HomeView: View {
    
    var selected = ["오늘의 푸디", "전체 푸디"]
    @State private var selectedCategory = 0
    @StateObject var viewModel = ContentViewModel()
    @State private var isToday: Bool = true
    
    var body: some View {
        NavigationStack {
            
            ScrollView {
                VStack{
                    HStack {
                        Text("뿌디뿌디")
                            .fontWeight(.bold)
                            .font(.title2)
                        Spacer()
                        
                        NavigationLink {
                            SearchView()
                        } label: {
                            Image(systemName: "magnifyingglass")
                                .font(.title2)
                                .foregroundColor(.black)
                        }
                        .navigationTitle("")
                        Image(systemName: "bell")
                            .font(.title2)
                        
                    }
                    .padding(.horizontal, 30)
                    .padding(.vertical, 30)
                    
                    HStack {
                        Button {
                            isToday = true
                        } label: {
                            
                            VStack(alignment: .center){
                                
                                Text("오늘의 뿌디")
                                    .font(.subheadline)
                                    .foregroundColor(isToday ? .black : .gray)
                                    .fontWeight(.semibold)
                                
                                Rectangle()
                                    .frame(width:70,height:2)
                                    .foregroundColor(isToday ? .black : .white)
                                
                            }
                            
                        }
                        
                        
                        Button {
                            isToday = false
                        } label: {
                            
                            VStack{
                                
                                Text("전체 뿌디")
                                    .font(.subheadline)
                                    .foregroundColor(isToday ? .gray : .black)
                                    .fontWeight(.semibold)
                                
                                Rectangle()
                                    .frame(width:60,height:2)
                                    .foregroundColor(isToday ? .white : .black)
                                
                                
                            }
                            
                        }
                        
                        
                    }
                    
                }
                .background(.white)
                
                
                
                if isToday {
                    ZStack {
                        Color("backgroundGray")
                        HStack {
                            Text("오늘의 뿌디터")
                                .font(.title)
                                .fontWeight(.bold)
                                .padding(.leading, 30)
                            Spacer()
                            NavigationLink(destination: CategoryView()) {
                                Image(systemName: "chevron.right")
                                    .font(.title)
                                    .foregroundColor(.black)
                                    .padding(.trailing,10)
                            }
                            .navigationBarTitle("")
                            .padding(.trailing, 20)
                        }
                        .padding(.top, 20)
                    .padding(.bottom,20)
                    }
                    SnapCarousel().environmentObject(viewModel.stateModel)
                    
                    
                    VStack {
                        HStack {
                            Text("🎓 오늘의 쩝쩝박사 뿌디뿌디")
                                .font(.title2)
                                .padding(.leading, 30)
                                .fontWeight(.semibold)
                                .padding(.bottom,20)
                            
                            Spacer()
                        } // HStack
                        
                        HStack {
                            Image("JJBaksa1")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("gold"), lineWidth: 2.7)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("lightgold"), lineWidth: 2.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                            
                            Image("JJBaksa2")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("gold"), lineWidth: 2.7)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("lightgold"), lineWidth: 2.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                            
                        }
                        
                        HStack {
                            Image("JJBaksa3")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("gold"), lineWidth: 2.7)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("lightgold"), lineWidth: 2.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                            Image("JJBaksa4")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("gold"), lineWidth: 2.7)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("lightgold"), lineWidth: 2.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                        }
                        
                    } // VStack 박사
                    .padding([.top, .bottom], 40)
                    
                    VStack {
                        HStack {
                            Text("🎓 오늘의 쩝쩝석사 뿌디뿌디")
                                .font(.title2)
                                .padding(.leading, 30)
                                .fontWeight(.semibold)
                                .padding(.bottom,20)
                            Spacer()
                        } // HStack
                        
                        HStack {
                            Image("JJSeoksa1")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("darkgray"), lineWidth: 3)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("silver"), lineWidth: 3)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                            Image("JJSeoksa2")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("darkgray"), lineWidth: 3)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("silver"), lineWidth: 3)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                        }
                        
                        HStack {
                            Image("JJSeoksa3")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("darkgray"), lineWidth: 3)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("silver"), lineWidth: 3)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                            Image("JJSeoksa4")
                                .overlay {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("darkgray"), lineWidth: 3)
                                    
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("silver"), lineWidth: 3)
                                        .shimmering(
                                            duration: 3
                                        )
                                }
                        }
                    } // VStack 석사
                    .padding(.bottom, 40)
                    
                    VStack {
                        HStack {
                            Text("🎓 오늘의 쩝쩝학사 뿌디뿌디")
                                .font(.title2)
                                .padding(.leading, 30)
                                .fontWeight(.semibold)
                                .padding(.bottom,20)
                            
                            Spacer()
                        } // HStack
                        
                        HStack {
                            Image("JJBaksa1")
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("bronze"), lineWidth: 3.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                )
                            Image("JJBaksa2")
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("bronze"), lineWidth: 3.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                )
                        }
                        
                        HStack {
                            Image("JJBaksa3")
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("bronze"), lineWidth: 3.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                )
                            Image("JJBaksa4")
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color("bronze"), lineWidth: 3.7)
                                        .shimmering(
                                            duration: 3
                                        )
                                )
                        }
                    } // VStack 학사
                    .padding(.bottom, 40)
                    
                } else {
                    VStack {
                        ZStack {
                            Color("backgroundGray")
                            Image("BestFootory")
                        }
//                            .padding(.leading,30)
//                            .padding(.vertical,30)
                        Image("TotalList")
                        
                        
                        
                    }
                }
            }
            
            
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
