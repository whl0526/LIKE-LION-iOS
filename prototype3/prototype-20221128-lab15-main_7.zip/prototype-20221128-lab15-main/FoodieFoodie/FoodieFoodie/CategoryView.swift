//
//  CategoryView.swift
//  FoodieFoodie
//
//  Created by 한승수 on 2022/11/29.
//

import SwiftUI

struct CategoryView: View {
    var body: some View {
        ScrollView {
            VStack {
                Text("뿌디터 카테고리")
                    .fontWeight(.bold)
                Image("CategoryCards")
            }
        }
    }
}

struct CategoryView_Previews: PreviewProvider {
    static var previews: some View {
        CategoryView()
    }
}
