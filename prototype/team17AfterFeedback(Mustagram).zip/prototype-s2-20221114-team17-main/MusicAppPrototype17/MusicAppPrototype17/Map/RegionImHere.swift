//
//  RegionImHere.swift
//  MusicAppPrototype17
//
//  Created by 김응관 on 2022/11/15.
//

import SwiftUI

struct RegionImHere: View {
    var body: some View {
        VStack{
            Image("sky")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: UIScreen.main.bounds.width)
                .padding(-2)
            NavigationLink(destination: ContentView()){
                Image("chooseMyPo")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: UIScreen.main.bounds.width)
                    .padding(-6)
            }
            Image("beach")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: UIScreen.main.bounds.width)
                .padding(-7)
            
        }
        .navigationBarBackButtonHidden(true)
        .ignoresSafeArea(.all)
    }
}

struct RegionImHere_Previews: PreviewProvider {
    static var previews: some View {
        RegionImHere()
    }
}
