//
//  RegionView.swift
//  MusicAppPrototype17
//
//  Created by 조형구 on 2022/11/14.
//

//import SwiftUI
//
//struct RegionView: View {
//    var body: some View {
//            VStack{
//                Image("sky")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: UIScreen.main.bounds.width)
//                    .padding(-2)
//                NavigationLink(destination: RegionImHere()) {
//                    Image("choosemapsss")
//                        .resizable()
//                        .aspectRatio(contentMode: .fit)
//                        .frame(width: UIScreen.main.bounds.width)
//                        .padding(-6)
//                }
//                Image("yangyang")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: UIScreen.main.bounds.width)
//                    .padding(-7)
//                NavigationLink(destination: PlayMusicView()) {
//                    Image("mapmusic")
//                        .resizable()
//                        .aspectRatio(contentMode: .fit)
//                        .frame(width: UIScreen.main.bounds.width)
//                }
//            }
//            .navigationBarBackButtonHidden(true)
//            .ignoresSafeArea(.all)
//    }
//}
//
//struct RegionView_Previews: PreviewProvider {
//    static var previews: some View {
//        RegionView()
//    }
//}
