//
//  FeedView.swift
//  MusicAppPrototype17
//
//  Created by 박성민 on 2022/11/16.
//

import SwiftUI

struct FeedView: View {
    @Binding var isPlayMusic: Bool
    @Binding var isMap: Bool
    @Binding var isfeed: Bool


    var body: some View {
        if isfeed {
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color("Color4"), Color("Color5"), Color("Color6")]), startPoint: .top, endPoint: .bottom).opacity(0.5).edgesIgnoringSafeArea(.all)
                Image("feedview4")
                    .resizable()
                VStack {
                    HStack{
                        Image("mustargram1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(.leading,20)
                            .padding(.trailing,100)
                        Button(action: { self.isMap.toggle()
                        }){
                            Image("mappin1")
                                .padding(.trailing,30)
                            
                        }
                    }
                    Button(action: { self.isfeed.toggle()
                    }){
                        Image("feedview1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(.bottom, 50)
                            .padding(30)
                    }
                }
                
                VStack{
                    Image("feedview2")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.horizontal, 60)
                        .padding(.top,160)
                }
                VStack{
                    HStack {
                        Image("feedview3")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(.vertical, 100)
                            .padding(.top,390)
                        Spacer()
                            .frame(width: 70)
                    }
                }
                
                VStack{
                    Spacer()
                    Button(action: { self.isPlayMusic.toggle()
                    }){
                        Image("musicbarbottom")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    }
                }
            }
            .fullScreenCover(isPresented: $isMap) {
                MapView1(isMap: $isMap)
            }
        } else {
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color("Color4"), Color("Color5"), Color("Color6")]), startPoint: .top, endPoint: .bottom).opacity(0.5).edgesIgnoringSafeArea(.all)
                VStack{
                    VStack{
                        HStack{
                            Image("bearImage")
                                .frame(width: 20, height:20)
                                .padding()
                            Text("바쿠성민상")
                                .font(.title2)
                                .fontWeight(.bold)
                            Spacer()
                            Button(action: { self.isfeed.toggle()
                            }){
                                Image(systemName: "chevron.down")
                                    .padding(.trailing,30)
                            }
                        }
                    }
                    Divider()
                    
                    VStack{
                        HStack{
                            Image("mappin1")
                            
                            Text("강원도 양양서피비치")
                                .font(.title3)
                                .fontWeight(.bold)
                        }.padding(.trailing, 165)
                            .padding(.bottom, -1)
                        
                    }
                    
                    VStack{
                        Image("addimage")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding([.trailing, .leading], 10)
                        Spacer()
                        
                    }
                    Divider()
                    HStack{
                        Image("AlbumCover1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 70, height: 70)
                            .padding(.trailing, 5)
                        VStack{
                            Text("Hypeboy")
                                .font(.system(size: 20))
                            Text("NewJeans")
                                .font(.system(size: 15))
                            
                        }
                        Spacer()
                        Image(systemName: "play")
                    }.padding([.trailing, .leading], 20)
                    Divider()
                    Spacer()
                    VStack(alignment: .leading){
                        Text("'양양 서피비치에서 하이삐보이이'")
                            .fontWeight(.bold)
                            .font(.title2)
                            .padding(.bottom, 3)
                        Text("서핑과 뉴진스 노래와 함께 즐기는 중!!")
                            .font(.body)
                            .padding(.leading, 5)
                        Divider()
                    }.padding()
                    List{
                        VStack(alignment: .leading){
                            HStack{
                                Image(systemName: "person.circle.fill")
                                    .frame(width: 10, height: 1)
                                    .padding()
                                Text("성민")
                                    .fontWeight(.bold)
                                
                                Text("뉴진스 사랑해요!")
                                    .padding(.leading, 5)
                                Spacer()
                                Image(systemName: "heart.fill")
                                    .foregroundColor(.red)
                            }
                            HStack{
                                Image(systemName: "person.circle.fill")
                                    .frame(width: 10, height: 1)
                                    .padding()
                                Text("영서")
                                    .fontWeight(.bold)
                                Text("뉴진스 사랑해요!")
                                    .padding(.leading, 5)
                                Spacer()
                                Image(systemName: "heart.fill")
                                    .foregroundColor(.red)
                            }
                            HStack{
                                Image(systemName: "person.circle.fill")
                                    .frame(width: 10, height: 1)
                                    .padding()
                                Text("응관")
                                    .fontWeight(.bold)
                                Text("바캉스 사랑해요!")
                                    .padding(.leading, 5)
                                Spacer()
                                Image(systemName: "heart.fill")
                                    .foregroundColor(.red)
                            }
                            HStack{
                                Image(systemName: "person.circle.fill")
                                    .frame(width: 10, height: 1)
                                    .padding()
                                Text("원형")
                                    .fontWeight(.bold)
                                Text("바다 사랑해요!")
                                    .padding(.leading, 5)
                                Spacer()
                                Image(systemName: "heart.fill")
                                    .foregroundColor(.red)
                            }
                            HStack{
                                Image(systemName: "person.circle.fill")
                                    .frame(width: 10, height: 1)
                                    .padding()
                                Text("소희")
                                    .fontWeight(.bold)
                                Text("뉴진스 사랑해요!")
                                    .padding(.leading, 5)
                                Spacer()
                                Image(systemName: "heart.fill")
                                    .foregroundColor(.red)
                            }
                            
                        }
                        .listRowBackground(Color.clear)

                    }
                    .listStyle(.plain)
                }
            }

        }
    }
}

//struct FeedView_Previews: PreviewProvider {
//    static var previews: some View {
//        FeedView()
//    }
//}
