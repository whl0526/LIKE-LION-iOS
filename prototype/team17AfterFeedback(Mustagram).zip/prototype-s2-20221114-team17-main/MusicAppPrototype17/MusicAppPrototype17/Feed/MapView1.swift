//
//  MapView1.swift
//  MusicAppPrototype17
//
//  Created by 박성민 on 2022/11/16.
//

import SwiftUI

struct MapView1: View {
    @Binding var isMap: Bool
    @State private var isMapToggle: Bool = true
    var body: some View {
        if isMapToggle {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color("Color4"), Color("Color5"), Color("Color6")]), startPoint: .top, endPoint: .bottom).opacity(0.5).edgesIgnoringSafeArea(.all)
                
                VStack{
                    RoundedRectangle(cornerRadius: 30)
                        .frame(width: 350, height: 80)
                        .foregroundColor(.white).opacity(0.5)
                    
                        .shadow(radius: 5, x: 5, y: 5)
                        .overlay {
                            Text("음악을 듣고싶은 장소")
                                .font(.title2)
                        }
                    Spacer()
                    Button(action: {
                        self.isMapToggle.toggle()
                    }){
                       Text("확인")
                            .font(.title)

                    }.padding(.bottom,100)
                }.padding(.top, 80)
                
                Picker(selection: /*@START_MENU_TOKEN@*/.constant(1)/*@END_MENU_TOKEN@*/, label: Text("Picker")) {
                    Text("강원도").tag(1)
                    Text("서울특별시").tag(2)
                    Text("대전광역시").tag(3)
                    Text("대구광역시").tag(4)
                    Text("부산광역시").tag(5)
                    Text("인천광역시").tag(6)
                    Text("광주광역시").tag(7)
                    Text("울산광역시").tag(8)
                    Text("세종특별자치시").tag(9)
                    Text("제주특별자치도").tag(10)
                    
                }.pickerStyle(.wheel)
                
                
            }.ignoresSafeArea()
            
        } else {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color("Color4"), Color("Color5"), Color("Color6")]), startPoint: .top, endPoint: .bottom).opacity(0.5).edgesIgnoringSafeArea(.all)

                 VStack{
                     RoundedRectangle(cornerRadius: 30)
                         .frame(width: 350, height: 80)
                         .foregroundColor(.white).opacity(0.5)
                         
                         .shadow(radius: 5, x: 5, y: 5)
                         .overlay {
                             Text("노래 장르")
                                 .font(.title2)
                         }
                     Spacer()
                     Button(action: {
                         self.isMap.toggle()

                         self.isMapToggle.toggle()
                     }){
                         Text("확인")
                              .font(.title)
                     }.padding(.bottom,100)
                 }.padding(.top, 80)
                 
                 Picker(selection: /*@START_MENU_TOKEN@*/.constant(1)/*@END_MENU_TOKEN@*/, label: Text("Picker")) {
                     Text("POP").tag(1)
                     Text("발라드").tag(2)
                     Text("국내힙합").tag(3)
                     Text("OST").tag(4)
                     Text("댄스").tag(5)
                     Text("성인가요/트로트").tag(6)
                     Text("CCM").tag(7)
                     Text("아이돌").tag(8)
                     Text("국내R&B").tag(9)
                     
                 }.pickerStyle(.wheel)

                 
             }.ignoresSafeArea()
            
        }
        
    }
    
    
}

//struct MapView1_Previews: PreviewProvider {
//    static var previews: some View {
//        MapView1()
//    }
//}
