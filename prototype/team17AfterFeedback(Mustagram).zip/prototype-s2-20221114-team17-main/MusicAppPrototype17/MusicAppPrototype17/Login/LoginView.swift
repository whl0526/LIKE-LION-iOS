//
//  LoginView.swift
//  MusicAppPrototype17
//
//  Created by 조형구 on 2022/11/14.
//
//완
import SwiftUI

struct LoginView: View {
    
    @Binding var isLogin: Bool

    
    var body: some View {
            
            ZStack{
                Image("loginview1")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                VStack{
                    Spacer()
                        .frame(height: 470)
                    Button(action: { self.isLogin.toggle()
                    }){
                        Image("loginview2")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(55)
                    }
                }
            
        }
    }
}
//
//struct LoginView_Previews: PreviewProvider {
//    static var previews: some View {
//        LoginView(isLogin: )
//    }
//}
