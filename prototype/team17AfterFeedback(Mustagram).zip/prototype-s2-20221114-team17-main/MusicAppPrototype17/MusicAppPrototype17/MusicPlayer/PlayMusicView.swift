//
//  PlayMusicView.swift
//  MusicAppPrototype17
//
//  Created by 조형구 on 2022/11/14.
//


import SwiftUI

struct PlayMusicView: View {
    @Binding var isPlayMusic: Bool
    @State var togglePlayList: Bool = true
    
    var body: some View {
        if togglePlayList {
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color("Color4"), Color("Color5"), Color("Color6")]), startPoint: .top, endPoint: .bottom).opacity(0.5).edgesIgnoringSafeArea(.all)
                VStack {
                    HStack {
                        Button(action: { self.isPlayMusic.toggle()
                        }){
                            Image(systemName: "chevron.down")
                                .padding(.leading,30)
                        }
                        Spacer()
                        VStack {
                            Text("Hype boy")
                                .font(.title2)
                                .bold()
                            Text("NEWJEANS")
                                .opacity(0.4)
                        }
                        Spacer()
                        
                        Image(systemName: "ellipsis")
                            .padding(.trailing,30)
                    }
                    .padding(.top,50)
                    Image("AlbumCover1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(30)
                    HStack{
                        Label("166,727", systemImage: "heart.fill")
                            .bold()
                            .padding(.leading)
                        Spacer()
                    }
                    
                    Text("누가 내게 뭐라든")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.blue)
                        .padding(.top)
                        .padding(.vertical,1)
                    Text("남들과 달라 넌")
                        .font(.title2)
                    
                    Image("playbar")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.horizontal)
                    Spacer()
                }
                VStack {
                    Spacer()
                    
                    Button(action: { self.togglePlayList.toggle()
                    }){
                        Image("bottombar2")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(.bottom,4)
                    }
                }
                .edgesIgnoringSafeArea(.bottom)
                
            }
        } else {
            
            
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color("Color4"), Color("Color5"), Color("Color6")]), startPoint: .top, endPoint: .bottom).opacity(0.5).edgesIgnoringSafeArea(.all)
                VStack {
                    VStack {
                        HStack{
                            Text("재생목록")
                                .font(.title2)
                                .bold()
                            Button(action: { self.isPlayMusic.toggle()
                            }){
                                Image(systemName: "chevron.down")
                            }
                        }
                        
                    }
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .padding(.leading,30)
                        Spacer()
                        Spacer()
                        
                        Image("modifybutton")
                            .resizable()
                            .frame(width: 44, height: 30)
                            .padding(.trailing,30)
                    }
                    Image("playlist1")
                        .resizable()
                        .frame(height: 650)
                        .padding(.horizontal,25)
                        .padding(.top,10)
                }
                .edgesIgnoringSafeArea(.bottom)
                VStack{
                    Spacer()
                    
                    Button(action: { self.togglePlayList.toggle()
                    }){
                        Image("bottombar1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(.bottom,4)
                    }
                }
                .edgesIgnoringSafeArea(.bottom)
            }
        }
    }
}

//struct PlayMusicView_Previews: PreviewProvider {
//    static var previews: some View {
//        PlayMusicView()
//    }
//}
