//
//  MusicAppPrototype17App.swift
//  MusicAppPrototype17
//
//  Created by 조형구 on 2022/11/14.
//

import SwiftUI

@main
struct MusicAppPrototype17App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
