//
//  ContentView.swift
//  MusicAppPrototype17
//
//  Created by 조형구 on 2022/11/14.
//

import SwiftUI

struct ContentView: View {
    @State private var selection: Int = 1
    @State private var isLogin: Bool = true
    @State private var isPlayMusic: Bool = false
    @State private var isMap: Bool = false
    @State private var isfeed: Bool = true




    
    init() {
        UITabBar.appearance().backgroundColor = UIColor(Color("Color7"))
        }
    
    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [Color("Color4"), Color("Color5"), Color("Color6")]), startPoint: .top, endPoint: .bottom).opacity(0.5).edgesIgnoringSafeArea(.all)
            NavigationStack {
                TabView(selection: $selection ){
                    
                    FeedView(isPlayMusic: $isPlayMusic, isMap: $isMap, isfeed: $isfeed).tabItem {
                        Image(systemName: "rectangle.grid.2x2.fill")
                        Text("뉴스피드")
                    }.tag(1)

                    MusicEssayView(isPlayMusic: $isPlayMusic, selection: $selection).tabItem {
                        Image(systemName: "plus")
                        Text("글 작성")
                    }.tag(2)
                    
                    MyPageView(isPlayMusic: $isPlayMusic).tabItem {
                        Image(systemName: "person")
                        Text("마이페이지")
                    }.tag(4)
                    
                }
                .navigationBarBackButtonHidden(true)
            }
            .fullScreenCover(isPresented: $isLogin) {
                LoginView(isLogin: $isLogin)
            }
        }
        
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
