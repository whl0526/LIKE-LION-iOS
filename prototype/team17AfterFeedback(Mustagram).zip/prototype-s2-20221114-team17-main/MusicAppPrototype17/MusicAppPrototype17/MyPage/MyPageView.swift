//
//  MyPageView.swift
//  MusicAppPrototype17
//
//  Created by 조형구 on 2022/11/14.
//

import SwiftUI

struct MyPageView: View {
    
    @Binding var isPlayMusic: Bool
    
    
    var body: some View {
        ZStack {
            Image("mypage1")
                .resizable()
                .aspectRatio(contentMode: .fill)
            VStack{
                Spacer()
                Button(action: { self.isPlayMusic.toggle()
                }){
                    Image("musicbarbottom")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.bottom,65)
                }
                
            }
        }
        .fullScreenCover(isPresented: $isPlayMusic) {
            PlayMusicView(isPlayMusic: $isPlayMusic)
            
                .edgesIgnoringSafeArea(.all)
        }
    }
}

//struct MyPageView_Previews: PreviewProvider {
//    static var previews: some View {
//        MyPageView()
//    }
//}

