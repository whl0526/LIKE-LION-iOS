//
//  UploadView.swift
//  Temp
//
//  Created by 한승수 on 2022/11/14.
//

import SwiftUI

struct UploadView: View {
    var body: some View {
        NavigationView {
            VStack {
                Text("사진을 업로드할 방법을 선택해주세요")
                    .font(.title2)
                    .padding(.top, 50)
                Spacer()
                
                Divider()
                
                Text("사진 촬영")
                    .font(.title3)
                    .padding()
                NavigationLink(destination: UploadDetailView()) {
                    Image(systemName: "camera.fill")
                        .resizable()
                        .frame(width: 65, height: 50)
                        .padding(.bottom, 40)
                }
                
                Divider()
                
                Text("사진 앱에서 추가")
                    .font(.title3)
                    .padding()
                NavigationLink(destination: UploadDetailView()) {
                    Image(systemName: "rectangle.and.paperclip")
                        .resizable()
                        .frame(width: 65, height: 50)
                        .padding(.bottom, 40)
                }
                Spacer()
            }
        }
    }
}

struct UploadView_Previews: PreviewProvider {
    static var previews: some View {
        UploadView()
    }
}
