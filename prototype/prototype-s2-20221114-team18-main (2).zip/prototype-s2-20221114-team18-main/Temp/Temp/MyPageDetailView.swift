//
//  MyPageDetailView.swift
//  Temp
//
//  Created by 김요한 on 2022/11/15.
//

import SwiftUI

struct MyPageDetailView: View {
    var body: some View {
        VStack {
            Image("detailImg")
                .resizable()
                .aspectRatio(contentMode: .fit)
            Button("air drop으로 공유하기"){}
            Button("instagram으로 공유하기"){}
        }
        
    }
}

struct MyPageDetailView_Previews: PreviewProvider {
    static var previews: some View {
        MyPageDetailView()
    }
}
