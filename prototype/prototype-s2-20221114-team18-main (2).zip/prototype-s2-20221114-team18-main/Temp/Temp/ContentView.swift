//
//  ContentView.swift
//  Temp
//
//  Created by 박진형 on 2022/11/14.
//

import SwiftUI

struct ContentView: View {
    
    @State private var selection = 1
   
    var body: some View {
    
            TabView(selection: $selection) {
                NavigationView {
                    HomeView()
                        .navigationTitle("여기 상단 뭐 넣을까요?")
                }
                .tabItem { Image(systemName: "music.note.house")
                    Text("홈") }.tag(1)
                
                NavigationView {
                    UploadView()
                        .navigationTitle("사진 업로드")
                }
                .tabItem {
                    Image(systemName: "square.and.arrow.up.circle.fill")
                    Text("사진 업로드") }.tag(2)
                NavigationView {
                    RecommendView()
                        .navigationTitle("사진에 어울리는 노래 추천하기")
                }
               .tabItem {
                    Image(systemName: "heart.square")
                    Text("추천") }.tag(3)
                
                NavigationView {
                    MyPageView()
                        .navigationTitle("마이페이지")
                }
                .tabItem {
                    Image(systemName: "person.circle.fill")
                    Text("마이페이지") }.tag(4)
            }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
