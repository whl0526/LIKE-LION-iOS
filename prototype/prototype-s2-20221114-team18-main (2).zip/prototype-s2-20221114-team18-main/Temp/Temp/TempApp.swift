//
//  TempApp.swift
//  Temp
//
//  Created by 박진형 on 2022/11/14.
//

import SwiftUI

@main
struct TempApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
