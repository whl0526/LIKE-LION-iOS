//
//  SelectUploadView.swift
//  Temp
//
//  Created by 한승수 on 2022/11/14.
//

import SwiftUI

struct SelectUploadView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SelectUploadView_Previews: PreviewProvider {
    static var previews: some View {
        SelectUploadView()
    }
}
