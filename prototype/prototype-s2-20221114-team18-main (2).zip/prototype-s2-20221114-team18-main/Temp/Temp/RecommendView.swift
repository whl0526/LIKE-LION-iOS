//
//  RecommendView.swift
//  Temp
//
//  Created by 김요한 on 2022/11/15.
//

import SwiftUI

struct RecommendView: View {
    var body: some View {
        VStack(alignment: .center) {
            Image("sunset")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width:350)
                .padding(.leading, 10)
                .padding(.trailing, 10)
                .padding(.top, 20)
            
            HStack(alignment: .top) {
                Text("#저녁")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
                Text("#노을")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
                Text("#따뜻함")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
                Text("#울적함")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
            }
            //추천 된 음악 리스트
            VStack(alignment: .leading) {
                List(){
                    HStack() {
                        Image("beforeSunrise")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width:40)
                            .border(.gray)
                        Spacer()
                        VStack{
                            Text("before sunrise")
                                .font(.title3)
                                .fontWeight(.bold)
                            Text("이적")
                        }
                        Spacer()
                    }
                    HStack {
                        Image("bigbang")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width:40)
                            .border(.gray)
                        Spacer()
                        VStack{
                            Text("붉은 노을")
                                .font(.title3)
                                .fontWeight(.bold)
                            Text("빅뱅")
                        }
                        Spacer()
                    }
                }
                .listStyle(.plain)
                .frame(width: 350,height: 100)
                
                
                
            }
            .padding()
            
            VStack {
                Button(action: {
                    // 액션
                }) {
                    HStack {
                        Text("노래 추천하기")
                            .fontWeight(.bold)
                            .font(.title3)
                    }
                    .frame(width: 300)
                    .padding()
                    .foregroundColor(.white)
                    .background(Color("titleBlue"))
                    .cornerRadius(10)
                    
                }
            }
            
            
            // 붉은 배경, 글자는 흰색 위의 와 같은 그림자 효과
            Button(action: {
                print("추천하지 않고 다음으로 넘어가기")
            }) {
                HStack {
                    Text("패스")
                        .font(.title3)
                }
                .frame(width: 300)
                .padding()
                .foregroundColor(.white)
                .background(Color.black)
                .cornerRadius(10)
            }
            
            
            
        }
    }
    
    
    struct RecommendView_Previews: PreviewProvider {
        static var previews: some View {
            RecommendView()
        }
    }
}
