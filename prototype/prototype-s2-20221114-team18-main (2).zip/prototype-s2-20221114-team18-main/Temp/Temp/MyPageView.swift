//
//  MyPageView.swift
//  Temp
//
//  Created by 김요한 on 2022/11/15.
//

import SwiftUI

struct MyPageView: View {
    let layout = [
        GridItem(.fixed(80)),
        GridItem(.fixed(80)),
        GridItem(.fixed(80))
    ]
    
    var body: some View {
        VStack {
            HStack{
                Image("profileImg")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .clipShape(Circle())
                    .frame(width: 110)
                
                VStack {
                    Text("닉네임")
                        .padding(5)
                    Button("프로필 수정하기"){}
                }
                Spacer()
            }
            //프로그래스 게이지바.?! 그래프?
            HStack {
                Image(systemName: "music.note.list")
                    .foregroundColor(Color("goldColor"))
                ProgressView("다음 등급까지...", value: 50, total: 100)
                    .padding()
            }
            
            
            //그리드
            Text("내가 업로드 한 사진")
            
            NavigationStack {
                ScrollView {
                    LazyVGrid(columns: layout) {
                        ForEach(0..<20) {_ in
                            NavigationLink(destination: {MyPageDetailView()}) {
                                Image("sunset")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }
                            
                        }
                    }
                }
            }
            
            
            
            
            
        }
        .padding()
    }
}

struct MyPageView_Previews: PreviewProvider {
    static var previews: some View {
        MyPageView()
    }
}
