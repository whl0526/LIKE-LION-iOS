//
//  UploadDetailView.swift
//  Temp
//
//  Created by 한승수 on 2022/11/14.
//

import SwiftUI

struct UploadDetailView: View {
    var body: some View {
        VStack {
            Image(systemName: "rectangle.fill")
                .resizable()
                .frame(width: 350, height: 250)
                .padding()
            HStack(alignment: .top) {
                Text("#태그1")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
                Text("#태그2")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
                Text("#태그3")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
                Text("#태그4")
                    .padding(.top, 7.5)
                    .padding(.bottom, 7.5)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(Color.black)
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .shadow(color: .gray, radius: 2, x: 0, y: 2))
            }
            Spacer()
            HStack {
                Image(systemName: "rectangle.fill")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .padding()
                VStack(alignment: .leading) {
                    Text("노래제목1")
                        .padding(1)
                    Text("가수1")
                }
                Spacer()
            }
            HStack {
                Image(systemName: "rectangle.fill")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .padding()

                VStack(alignment: .leading) {
                    Text("노래제목2")
                        .padding(1)
                    Text("가수2")
                }
                Spacer()

            }
            HStack {
                Image(systemName: "rectangle.fill")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .padding()

                VStack(alignment: .leading) {
                    Text("노래제목3")
                        .padding(1)
                    Text("가수3")
                }
                Spacer()

            }
            Spacer()
            Button {
                
            } label: {
                Text("커뮤니티에서 추천 받기")
            }
            Spacer()

        }
    }
}

struct UploadDetailView_Previews: PreviewProvider {
    static var previews: some View {
        UploadDetailView()
    }
}
