//
//  HomeView.swift
//  Temp
//
//  Created by 박진형 on 2022/11/14.
//

import SwiftUI

struct HomeView: View {
    
    @StateObject var viewModel = ContentViewModel()
    let backGrounds: [String] = ["moon", "electric", "firework", "van"]
    let idArray: [String] = ["jinjin9696", "circles0526", "valse", "borijam"]
    let songArray: [String] = ["fly me to the moon", "electric shock", "불꽃 놀이", "Vancouver"]
    let singerArray: [String] = ["frank Sinatra", "f(x)", "다이나믹 듀오", "서동현"]
    
    
    var body: some View {
        ZStack {
            Color(uiColor: UIImage(named: backGrounds[viewModel.activeCard])?.averageColor ?? UIColor.clear).ignoresSafeArea()
            VStack(spacing: 8) {
                SnapCarousel()
                    .environmentObject(viewModel.stateModel)
                Spacer()
                Spacer()
                Spacer()
                Spacer()
                Text(idArray[viewModel.activeCard])
                Text("가장 많이 추천 받은 노래")
                Spacer()
                Text(songArray[viewModel.activeCard])
                    .font(.title)
                
                Text(singerArray[viewModel.activeCard])
                
            } // VStack
            .frame(height: 350, alignment: .center)
            .foregroundColor(.white)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
