//
//  WebService.swift
//  ListNavDemo
//
//  Created by 이재희 on 2022/11/22.
//  Copyright © 2022 eBookFrenzy. All rights reserved.
//

import Foundation

class WebService {
    func fetchData(url: String) async throws -> [Car] {
        guard let url = URL(string: url) else { return [] }
        
        let (data, _) = try await URLSession.shared.data(from: url)
        let cars = try JSONDecoder().decode([Car].self, from: data)
        
        return cars
    }
}
