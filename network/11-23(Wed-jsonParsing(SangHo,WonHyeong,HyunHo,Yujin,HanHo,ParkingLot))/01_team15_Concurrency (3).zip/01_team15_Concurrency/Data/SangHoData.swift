//
//  SangHoData.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import Foundation

struct Characters : Codable,Hashable {
    var name: String
    var dateOfBirth: String
    var wizard: Bool
    
    
}

class CharactersStore : ObservableObject {

    @Published var characters: [Characters]

    init (characters: [Characters] = []) {
        self.characters = characters
    }
}
