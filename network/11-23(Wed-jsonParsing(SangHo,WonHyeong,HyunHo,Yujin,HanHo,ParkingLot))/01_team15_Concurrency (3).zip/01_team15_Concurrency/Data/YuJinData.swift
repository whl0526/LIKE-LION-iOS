//
//  YuJinData.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import Foundation

struct Departments : Codable, Hashable {
    var departments: [DepartmentsValue]
} // 키값에 대한 구조체는 [배열]형식의 변수를 가지고

struct DepartmentsValue : Codable, Hashable {
    var departmentId: Int
    var displayName: String
}

class DepartmentsStore : ObservableObject {
    
    @Published var departments: [DepartmentsValue]
    
    init (departments: [DepartmentsValue] = []) {
        self.departments = departments
    }
}
