//
//  _1_team15_ConcurrencyApp.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI

@main
struct _1_team15_ConcurrencyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
