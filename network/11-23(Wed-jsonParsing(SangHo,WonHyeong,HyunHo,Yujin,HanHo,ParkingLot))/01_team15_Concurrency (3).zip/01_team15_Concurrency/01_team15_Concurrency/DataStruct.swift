//
//  DataStruct.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import Foundation

// 한호님
struct BoxOffice: Codable {
    var boxOfficeResult: WeeklyBoxOffice
}

struct WeeklyBoxOffice: Codable {
    var weeklyBoxOfficeList: [WeeklyBoxOfficeList]
    var showRange: String
}

struct WeeklyBoxOfficeList: Codable {
    var rank: String        // 순위
    var movieNm: String     // 영화 이름
    var openDt: String      // 개봉일
    var salesAmt: String    // 매출
    var salesAcc: String    // 누적 매출액
    var audiCnt: String     // 관객수
    var audiAcc: String     // 누적 관객수
}

struct Food : Codable {
    var status: String
    var total: String
    var data: [DataInfo]
}

struct DataInfo: Codable {
    var MNU: String
}

// 상호님
struct Characters : Codable {
    var name: String
    var dateOfBirth: String
    var wizard: Bool
    
}

// 유진님
struct GhibliData : Codable, Hashable {
    // 임의 저장소 만들기
    var id: String
    var title: String
    var image: String
    var description: String
    var director: String
    var producer: String
    var release_date: String
    var running_time: String
    var people: [String]
    var url: String
    var peopleInfo: [PeopleData]?
}

struct PeopleData: Codable, Hashable {
    var id: String
    var name: String
    var gender: String?
    var age: String
}
