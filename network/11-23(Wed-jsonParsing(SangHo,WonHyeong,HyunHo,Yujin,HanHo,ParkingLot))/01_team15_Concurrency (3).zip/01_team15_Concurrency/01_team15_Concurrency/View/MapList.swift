//
//  MapList.swift
//  01_team15_Concurrency
//
//  Created by 추현호 on 2022/11/23.
//

import SwiftUI

struct MapList: View {
    
    @ObservedObject var parkinglotStore: ParkingLotStore
    
    let webService: ParkingLotDecode = ParkingLotDecode()
    
    let url: String = "http://211.252.37.224/rest/parking"
    
    var body: some View {
        List{
            ForEach(parkinglotStore.parking, id: \.self) { item in
                NavigationLink(destination: ParkingLotView(parkingInfoList: item)) {
                    VStack{
                        Text("\(item.parkingName)")
                    }
                }
            }
        }.onAppear(perform: {
            print("1111")
            Task {
                    parkinglotStore.parking = try await webService.fetchData(url: url)
                    print("\(parkinglotStore.parking)")
            }
        })
    }
}
