//
//  ParkingLotView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI
import MapKit

struct AnnotatedItem: Identifiable {
    let id = UUID()
    var name: String
    var coordinate: CLLocationCoordinate2D
}

var pointsOfInterest: [AnnotatedItem] = []


struct ParkingLotView: View {
    
    @State private var region: MKCoordinateRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.75773, longitude: -73.985708),
        span: MKCoordinateSpan(latitudeDelta: 0.04, longitudeDelta: 0.04)
    )
    
    let parkingInfoList: ParkingInfoList
    
    
    
    var body: some View {
        VStack {
            Text("\(parkingInfoList.parkingName)")
            Text("\(parkingInfoList.addrJibun)")
            Map(coordinateRegion: $region,
                annotationItems: pointsOfInterest) { item in
                MapMarker(coordinate: item.coordinate)
            }
        }
        .onAppear(perform: {
            region.center.latitude = Double(parkingInfoList.lat) ?? 0
            region.center.longitude = Double(parkingInfoList.lng) ?? 0
            pointsOfInterest.append(
                AnnotatedItem(name: parkingInfoList.parkingName,
                              coordinate:
                                CLLocationCoordinate2D(latitude: Double(parkingInfoList.lat) ?? 0,
                                                       longitude: Double(parkingInfoList.lng) ?? 0)
                             )
            )
        })
    }
}
