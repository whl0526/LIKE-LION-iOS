//
//  YuJinView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI
import Charts

struct YuJinView: View {
    
    @ObservedObject var departmentStore: DepartmentsStore = DepartmentsStore(departments: [])
    
    var webservice: YuJin = YuJin()
    
    let url: String = "https://collectionapi.metmuseum.org/public/collection/v1/departments"
    
    var body: some View {
        VStack{
            Chart {
                ForEach(departmentStore.departments, id: \.self){ department in
                    LineMark(x: .value("name", department.displayName),
                             y: .value("departmentId", department.departmentId))
                }
            }
        }.onAppear {
            Task {
                departmentStore.departments = try await webservice.fetchData(url: url)
            }
        }
    }
}

struct YuJin_Previews: PreviewProvider {
    static var previews: some View {
        YuJinView()
    }
}
