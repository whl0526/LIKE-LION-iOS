//
//  ContentView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject var parkinglotStore: ParkingLotStore = ParkingLotStore()
    
    var body: some View {
        NavigationStack{
            VStack {
                List {
                    NavigationLink(destination: SangHoView(), label: {HStack{
                        Text("박상호")
                        Text("해리포터")
                    }})
                    
                    NavigationLink(destination: WonHyeongView(), label: {HStack{
                        Text("이원형")
                        Text("대구 맛집")
                    }})
                    
                    NavigationLink(destination: HyunHoView(), label: {HStack{
                        Text("추현호")
                        Text("아직 모름")
                    }})
                    
                    NavigationLink(destination: HanHoView(), label: {HStack{
                        Text("최한호")
                        Text("주말 박스오피스")
                    }})
                    
                    NavigationLink(destination: YuJinView(), label: {HStack{
                        Text("황유진")
                        Text("박물관")
                    }})
                    NavigationLink(destination: MapList(parkinglotStore: parkinglotStore), label: {HStack{
                        Text("주차장")
                        Text("위치")
                    }})
                    
                }
            }
            .navigationBarTitle("Team 15")
        }
    }
    
}
