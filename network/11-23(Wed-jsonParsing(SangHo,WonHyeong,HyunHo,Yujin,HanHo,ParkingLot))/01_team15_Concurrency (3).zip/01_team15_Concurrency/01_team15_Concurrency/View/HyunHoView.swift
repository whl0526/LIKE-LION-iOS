//
//  HyunHoView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI

struct HyunHoView: View {
    
    @ObservedObject var digimonStore: DigimonStore = DigimonStore(digimons: [])
    @ObservedObject var digimonImageStore: DigimonImageStore = DigimonImageStore(digimonImages: [])
    
    var webservice: HyunHo = HyunHo()
    var imageWebService: DigimonDecoder = DigimonDecoder()
    
    
    
    let url: String = "https://www.digi-api.com/api/v1/digimon"
    let detailUrl: String = "https://www.digi-api.com/api/v1/digimon/1"
    
    var body: some View {
        List {
            ForEach(digimonImageStore.digimonImages, id: \.self){
                digimon in VStack {
                    AsyncImage(url: URL(string: digimon.href)) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                }
            }
        }.onAppear {
            Task {
                
                digimonStore.digimons = try await webservice.fetchData(url: url)
                
                
                digimonImageStore.digimonImages = try await imageWebService.fetchData(url: detailUrl)
                
            }
        }
    }
}

struct HyunHoView_Previews: PreviewProvider {
    static var previews: some View {
        HyunHoView()
    }
}
