//
//  ParkingLotView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI
import MapKit

struct AnnotatedItem: Identifiable {
    let id = UUID()
    var name: String
    var coordinate: CLLocationCoordinate2D
}

struct ParkingLotView: View {
    
    var location: (Double, Double)
    init(location: (Double, Double)) {
        self.location = location
    }
    
    @State private var region: MKCoordinateRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 40.75773, longitude: -73.985708),
        span: MKCoordinateSpan(latitudeDelta: 0.04, longitudeDelta: 0.04)
    )
    
    var body: some View {
        
        let pointsOfInterest = [
            AnnotatedItem(name: "ParkingLot", coordinate: .init(latitude: location.0,longitude: location.1))
        ]
        NavigationStack{
            VStack {
                Map(coordinateRegion: $region, annotationItems: pointsOfInterest) {
                    item in
                    MapMarker(coordinate: item.coordinate, tint: .purple)
                }
                .onAppear {
                    region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: location.0, longitude: location.1), span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
                }
            }
            //        VStack {
            //            Text("\(parkingInfoList.parkingName)")
            //            Text("\(parkingInfoList.addrJibun)")
            //            Map(coordinateRegion: $region,
            //                annotationItems: pointsOfInterest) { item in
            //                MapMarker(coordinate: item.coordinate)
            //            }
            //        }
            //        .onAppear(perform: {
            //            region.center.latitude = Double(parkingInfoList.lat) ?? 0
            //            region.center.longitude = Double(parkingInfoList.lng) ?? 0
            //            pointsOfInterest.append(
            //                AnnotatedItem(name: parkingInfoList.parkingName,
            //                              coordinate:
            //                                CLLocationCoordinate2D(latitude: Double(parkingInfoList.lat) ?? 0,
            //                                                       longitude: Double(parkingInfoList.lng) ?? 0)
            //                             )
            //            )
            //        })
            //    }
        }
    }
}
