
//  TotalParkingLot.swift
//  01_team15_Concurrency
//
//  Created by 이원형 on 2022/11/24.
//

import SwiftUI
import MapKit

struct EntireParkingLotView: View {
    
    @ObservedObject var parkinglotStore: ParkingLotStore
    
    let webService: ParkingLotDecode = ParkingLotDecode()
    let url: String = "http://211.252.37.224/rest/parking"
    
    struct AnnotatedItem: Identifiable {
        let id = UUID()
        var name: String
        var coordinate: CLLocationCoordinate2D
    }
    
    @State private var region: MKCoordinateRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 37.808208, longitude: -122.415802), span: MKCoordinateSpan(latitudeDelta: 0.02, longitudeDelta: 0.02))
    
    @State private var pointsOfInterest: [AnnotatedItem] = []
    
    var body: some View {
        VStack {
            
            Map(coordinateRegion: $region, annotationItems: pointsOfInterest) { item in
                MapMarker(coordinate: item.coordinate, tint: .blue)
            }
            .navigationTitle("드디어 성공ㅎㅅㅎ")
            .onAppear {
                Task {
                    parkinglotStore.parking = try await webService.fetchData(url: url)
                    for item in parkinglotStore.parking {
                        //이거 신박하다잉.
                        let coordinate = CLLocationCoordinate2D(latitude: Double(item.lat) ?? 0.0 , longitude: Double(item.lng) ?? 0.0 )
                        let annotatedItem = AnnotatedItem(name: "", coordinate: coordinate)
                        
                        pointsOfInterest.append(annotatedItem)
                        region.center = coordinate
                    }
                }
            }
        }
    }
}
