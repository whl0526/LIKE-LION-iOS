//
//  DecodingJson.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import Foundation

class SangHo {
    
    func fetchData(url: String) async throws -> [Characters] {
        guard let url = URL(string: url) else { return [] }
        
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        
        let characters = try JSONDecoder().decode([Characters].self, from: data)
        
        return characters
    }
}

class WonHyeong {
    
    func fetchData(url: String) async throws -> [DataInfo] {
        guard let url = URL(string: url) else { return [] }
        
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        
        let food = try JSONDecoder().decode(Food.self, from: data)
        
        return food.data
    }
}

class HyunHo {
    
    func fetchData(url: String) async throws -> [Digimon] {
        guard let url = URL(string: url) else { return [] }
        
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        
        let digimons = try JSONDecoder().decode(TotalData.self, from: data)
        
        return digimons.content
    }
}


class DigimonDecoder {
    
    func fetchData(url: String) async throws -> [DigimonImage] {
        guard let url = URL(string: url) else { return [] }
        
        
        let (data, _) = try await URLSession.shared.data(from: url)
        
        
        let digimonImages = try JSONDecoder().decode(DigimonDetail.self, from: data)
        
        
        
        return digimonImages.images
    }
}


class YuJin {
    
    func fetchData(url: String) async throws -> [DepartmentsValue] {
        
        guard let url = URL(string: url) else { return [] }
        
       
        let datas = try await URLSession.shared.data(from: url)
        
       
        let work = try JSONDecoder().decode(Departments.self, from: datas.0)
        
        return work.departments
    }
}

class HanHo {
    
    func fetchData(url: String) async throws -> [WeeklyBoxOfficeList] {
        
        guard let url = URL(string: url) else { return [] }
        
       
        let datas = try await URLSession.shared.data(from: url)
        
       
        let movies = try JSONDecoder().decode(BoxOffice.self, from: datas.0)
        
        return movies.boxOfficeResult.weeklyBoxOfficeList
    }
}

class ParkingLotDecode {
    
    func fetchData(url: String) async throws -> [ParkingInfoList] {
        
        print("1")
        
        guard let url = URL(string: url) else { return [] }
        
       
        let (data, _) = try await URLSession.shared.data(from: url)
        
       
        let parking = try JSONDecoder().decode(ParkingInfo.self, from: data)
        
        print(parking)
        
        return parking.parkingInfoList
    }
}
