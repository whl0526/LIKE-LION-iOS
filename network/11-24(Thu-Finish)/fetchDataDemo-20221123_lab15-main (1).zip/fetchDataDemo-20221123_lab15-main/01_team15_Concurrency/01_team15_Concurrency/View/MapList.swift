//
//  MapList.swift
//  01_team15_Concurrency
//
//  Created by 추현호 on 2022/11/23.
//

import SwiftUI

struct MapList: View {
    
    @ObservedObject var parkinglotStore: ParkingLotStore
    
    let webService: ParkingLotDecode = ParkingLotDecode()
    
    let url: String = "http://211.252.37.224/rest/parking"
    
    var body: some View {
        List{
            ForEach(parkinglotStore.parking, id: \.self) { item in
                NavigationLink(destination: ParkingLotView(location:(Double(item.lat) ?? 0, Double(item.lng) ?? 0))) {
                    VStack{
                        Text("\(item.parkingName)")
                    }
                }
            }
            NavigationLink {
                EntireParkingLotView(parkinglotStore: parkinglotStore)
            } label: {
                Text("전체위치")
            }
        }.onAppear(perform: {
            Task {
                    parkinglotStore.parking = try await webService.fetchData(url: url)
                    print("\(parkinglotStore.parking)") // [ParkingInfoList]
            }
        })
    }
}
