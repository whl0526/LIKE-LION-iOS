//
//  HanHoView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI

struct HanHoView: View {
    
    @ObservedObject var moviesStore: Movies = Movies(movies: [])
    
    var webservice: HanHo = HanHo()
    
    let url: String = "http://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchWeeklyBoxOfficeList.json?key=baec1bdd326e42e3f8aad1a7c9b33406&targetDt=20221118"
    
    var body: some View {
        List {
            ForEach(moviesStore.movies, id: \.self){
                movie in VStack {
                    Text("\(movie.movieNm)")
                }
            }
        }.onAppear {
            Task {
                moviesStore.movies = try await webservice.fetchData(url: url)
            }
        }
    }
}

struct HanHoView_Previews: PreviewProvider {
    static var previews: some View {
        HanHoView()
    }
}
