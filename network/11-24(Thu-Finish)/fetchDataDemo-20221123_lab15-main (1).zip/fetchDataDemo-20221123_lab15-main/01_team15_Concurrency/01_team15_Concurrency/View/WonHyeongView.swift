//
//  WonHyeongView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI

struct WonHyeongView: View {
    
    @ObservedObject var foodStore: FoodStore =
    FoodStore(food: [])
    
    let url: String = "https://mocki.io/v1/68e2942d-de2c-4987-87cd-53e29a560c70"
    
    var webService: WonHyeong = WonHyeong()
    
    var body: some View {
        VStack{
            
            List {
                ForEach(foodStore.food, id: \.self){
                    food in VStack {
                        Text("\(food.menu)")
                    }
                }
            }.onAppear{
                Task{
                foodStore.food = try await webService.fetchData(url: url)
                
            }}
        }
    }
}

struct WonHyeongView_Previews: PreviewProvider {
    static var previews: some View {
        WonHyeongView()
    }
}
