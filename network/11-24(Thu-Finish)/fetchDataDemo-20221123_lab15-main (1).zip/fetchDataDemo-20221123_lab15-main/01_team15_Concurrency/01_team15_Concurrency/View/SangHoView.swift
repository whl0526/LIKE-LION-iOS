//
//  SangHoView.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import SwiftUI

struct SangHoView: View {
    
    
    @ObservedObject var charactersStore: CharactersStore =
    CharactersStore(characters: [])
    
    let url: String = "https://hp-api.herokuapp.com/api/characters"
    var webService: SangHo = SangHo()
    
    var body: some View {
        
        VStack{

            List {
                ForEach(charactersStore.characters, id: \.self){
                    character in VStack {
                        Text("\(character.name)")
                    }
                }
            }.onAppear{Task{
                charactersStore.characters = try await webService.fetchData(url: url)

            }}
        }

    }
}

struct SangHoView_Previews: PreviewProvider {
    static var previews: some View {
        SangHoView()
    }
}
