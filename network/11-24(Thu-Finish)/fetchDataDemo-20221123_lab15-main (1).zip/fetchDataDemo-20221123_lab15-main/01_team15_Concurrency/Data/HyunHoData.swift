//
//  HyunHoData.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import Foundation

struct TotalData: Decodable, Hashable {
    let content: [Digimon]
    let pageable: Pageable
}

struct Digimon: Decodable, Hashable {
    let id: Int
    let name: String
    let href: String
}

struct Pageable: Decodable, Hashable {
    let currentPage, elementsOnPage, totalElements, totalPages: Int
    let previousPage: String
    let nextPage: String
}

class DigimonStore : ObservableObject {
    
    @Published var digimons: [Digimon]
    
    init (digimons: [Digimon] = []) {
        self.digimons = digimons
    }
}

struct DigimonDetail: Codable, Hashable {
    let id: Int
    let name: String
    let images: [DigimonImage]
}

struct DigimonImage: Codable, Hashable {
    let href: String
}

class DigimonImageStore: ObservableObject {
    
    @Published var digimonImages: [DigimonImage]
    
    init (digimonImages: [DigimonImage] = []) {
        self.digimonImages = digimonImages
    }
}






