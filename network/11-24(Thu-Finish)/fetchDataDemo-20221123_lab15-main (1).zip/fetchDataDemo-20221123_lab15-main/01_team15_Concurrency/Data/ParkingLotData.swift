//
//  ParkingLotData.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import Foundation


struct ParkingInfo: Codable, Hashable {
    var resultCode: String
    var resultMsg: String
    var pageIndex: String
    var pageSize: String
    var startPage: String
    var totalCount: String
    var parkingInfoList: [ParkingInfoList]
}

struct ParkingInfoList: Codable, Hashable {
    var parkingName: String
    var lat: String
    var lng: String
}


class ParkingLotStore : ObservableObject {
    
    @Published var parking: [ParkingInfoList]
    
    init (parking: [ParkingInfoList] = []) {
        self.parking = parking
    }
}
