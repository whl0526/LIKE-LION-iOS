//
//  WonHyeongData.swift
//  01_team15_Concurrency
//
//  Created by Yooj on 2022/11/23.
//

import Foundation

struct Food : Codable, Hashable {
    var status: String
    var total: String
    var data: [DataInfo]
}

struct DataInfo: Codable, Hashable {
    
    enum CodingKeys: String, CodingKey {
        case menu = "MNU"
    }

    var menu: String
}


class FoodStore : ObservableObject {
    
    @Published var food: [DataInfo]
    
    init (food: [DataInfo] = []) {
        self.food = food
    }
}
