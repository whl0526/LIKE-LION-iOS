# fetchDataDemo-20221123_lab15

## 참고데이터

### JSON API

#### SanghoView (해리포터 등장인물) : "https://hp-api.herokuapp.com/api/characters"
#### WonhyeongView (대구 맛집) : "https://mocki.io/v1/68e2942d-de2c-4987-87cd-53e29a560c70"
#### HyunHoView (디지몬) : "https://www.digi-api.com/api/v1/digimon"
#### YuJinView (박물관) : "https://collectionapi.metmuseum.org/public/collection/v1/departments"
#### HanHoView (박스오피스 순위) : "http://kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchWeeklyBoxOfficeList.json?key=baec1bdd326e42e3f8aad1a7c9b33406&targetDt=20221118"


## 스크린샷
<img width="495" alt="스크린샷 2022-11-24 17 57 12" src="https://user-images.githubusercontent.com/67450169/203737609-d483f9da-4ef4-495b-81b9-c8883265faad.png">
<img width="495" alt="스크린샷 2022-11-24 17 57 16" src="https://user-images.githubusercontent.com/67450169/203737677-d00f58fe-ed9a-4fec-ae82-ae87cc6ef17a.png">
<img width="495" alt="스크린샷 2022-11-24 17 57 26" src="https://user-images.githubusercontent.com/67450169/203737718-291318ec-120c-4bc0-82cb-19e1eec1abc9.png">
<img width="495" alt="스크린샷 2022-11-24 17 57 36" src="https://user-images.githubusercontent.com/67450169/203737802-a8bb5a93-284e-423e-89e6-e4b9ded4a117.png">
<img width="495" alt="스크린샷 2022-11-24 17 57 38" src="https://user-images.githubusercontent.com/67450169/203737855-105b7f55-a1a7-4397-a0bd-e96733978a6c.png">
<img width="495" alt="스크린샷 2022-11-24 17 57 43" src="https://user-images.githubusercontent.com/67450169/203737903-9b21cb2e-81d5-496f-a4ef-12f355eeac7a.png">

## 참여자
 | <img src="https://avatars.githubusercontent.com/u/114331071?v=4" width=200> | <img src="https://avatars.githubusercontent.com/u/64696968?v=4" width=200> | <img src="https://avatars.githubusercontent.com/u/67450169?v=4" width=200> | <img src="https://avatars.githubusercontent.com/u/109830398?v=4" width=200> | <img src="https://avatars.githubusercontent.com/u/114223996?v=4" width=200> |
| :----------------------------------------------------------: | :---------------------------------------------: | :-------------------------------------------------: | :-------------------------------------------------: |  :-------------------------------------------------: |
| 유진<br/>[@yooj1202](https://github.com/yooj1202)<br/> | 최한호<br/>[@guguhanogu](https://github.com/guguhanogu)<br/> | 이원형<br/> [@whl0526](https://github.com/whl0526)<br/> | 추현호<br/>[@HHCHO0220](https://github.com/HHCHO0220)<br/> | 박상호<br/>[@RoCo-10000hours](https://github.com/RoCo-10000hours)<br/> |




